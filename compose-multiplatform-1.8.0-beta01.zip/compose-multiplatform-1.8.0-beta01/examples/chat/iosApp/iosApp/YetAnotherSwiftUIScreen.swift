import SwiftUI

struct YetAnotherSwiftUIScreen: View {
    var body: some View {
        GradientTemplate(title: "SwiftUI") {
            VStack {
                Text("Yet another SwiftUI screen")
            }
        }
    }
}
