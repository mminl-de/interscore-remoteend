import androidx.compose.runtime.Composable

@Composable
fun MainView() = ChatAppWithScaffold()


