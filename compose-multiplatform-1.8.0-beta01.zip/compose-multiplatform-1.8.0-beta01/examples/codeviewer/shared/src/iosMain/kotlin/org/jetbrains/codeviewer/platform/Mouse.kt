package org.jetbrains.codeviewer.platform

import androidx.compose.ui.Modifier

actual fun Modifier.cursorForHorizontalResize(): Modifier = this
