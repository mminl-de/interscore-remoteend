import androidx.compose.runtime.Composable
import org.jetbrains.codeviewer.ui.MainView

@Composable
fun MainView() = MainView()