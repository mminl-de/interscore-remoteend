package org.jetbrains.codeviewer.platform

import androidx.compose.ui.Modifier

expect fun Modifier.cursorForHorizontalResize(): Modifier