rootProject.name = "compose-uber-jar"

