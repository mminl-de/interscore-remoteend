Compose Web Application

- `./gradlew jsBrowserRun` - run application in a browser
- `./gradlew jsBrowserProductionWebpack` - produce the output in `build/distributions`