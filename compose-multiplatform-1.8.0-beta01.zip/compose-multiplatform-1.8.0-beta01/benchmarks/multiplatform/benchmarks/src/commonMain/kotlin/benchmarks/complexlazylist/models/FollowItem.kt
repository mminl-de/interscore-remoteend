package benchmarks.complexlazylist.models

class FollowItem() : IBaseViewModel {
    override val blockId: String?
        get() = TODO("Not yet implemented")
    override val reportInfo: Map<String, Any>?
        get() = TODO("Not yet implemented")
    override val operations: Map<String, Any>?
        get() = TODO("Not yet implemented")
    override val flipInfos: Map<String, Any>?
        get() = TODO("Not yet implemented")
    override val extraData: Map<String, Any>?
        get() = TODO("Not yet implemented")
    override val data: Map<String, Any>?
        get() = TODO("Not yet implemented")
}