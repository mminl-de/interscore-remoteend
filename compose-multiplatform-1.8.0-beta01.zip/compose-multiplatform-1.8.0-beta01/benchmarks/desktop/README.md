Collection of Jetpack Compose for Desktop related benchmarks.

It uses [kotlinx.benchmark](https://github.com/Kotlin/kotlinx-benchmark), to run all benchmarks execute `./gradlew mainBenchmar`