To start performance tests:  
`./gradlew runIde`
