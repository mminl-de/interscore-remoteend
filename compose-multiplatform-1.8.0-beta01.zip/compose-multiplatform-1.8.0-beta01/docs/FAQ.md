This document has been moved to [https://www.jetbrains.com/help/kotlin-multiplatform-dev/faq.html](https://www.jetbrains.com/help/kotlin-multiplatform-dev/faq.html).

To edit the document, open [https://github.com/JetBrains/kotlin-multiplatform-dev-docs/blob/master/topics/overview/faq.md](https://github.com/JetBrains/kotlin-multiplatform-dev-docs/blob/master/topics/overview/faq.md).