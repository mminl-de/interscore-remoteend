import androidx.compose.runtime.Composable

actual val Abc.composableIntVal: Int
    @Composable get () = 100