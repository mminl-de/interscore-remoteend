actual val Abc.composableIntVal: Int
    get() = 100