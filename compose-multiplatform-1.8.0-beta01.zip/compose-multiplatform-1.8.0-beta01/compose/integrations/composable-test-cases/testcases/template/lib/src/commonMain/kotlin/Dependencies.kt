import androidx.compose.runtime.Composable
import com.example.common.TextLeafNode

@Composable
fun SimpleComposable() {
    TextLeafNode("SimpleComposable")
}
