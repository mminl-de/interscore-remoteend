import androidx.compose.runtime.Composable

interface HasComposable2 {
    @Composable
    fun Abc()
}
