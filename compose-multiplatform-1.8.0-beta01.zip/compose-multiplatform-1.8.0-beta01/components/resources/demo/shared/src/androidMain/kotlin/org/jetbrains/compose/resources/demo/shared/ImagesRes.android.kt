package org.jetbrains.compose.resources.demo.shared

import androidx.compose.runtime.Composable

@Composable
actual fun SvgShowcase() {
    //Android platform doesn't support SVG resources
}