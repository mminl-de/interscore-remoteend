// Setting this will make the tests use a blocking XMLHttpRequest instead of the asynchronous 'fetch'
window.composeResourcesTesting = true;