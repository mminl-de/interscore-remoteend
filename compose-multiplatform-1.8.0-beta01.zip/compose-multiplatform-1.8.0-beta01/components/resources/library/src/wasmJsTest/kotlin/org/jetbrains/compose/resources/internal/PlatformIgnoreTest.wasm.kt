package org.jetbrains.compose.resources.internal

actual typealias IgnoreWasmTest = kotlin.test.Ignore