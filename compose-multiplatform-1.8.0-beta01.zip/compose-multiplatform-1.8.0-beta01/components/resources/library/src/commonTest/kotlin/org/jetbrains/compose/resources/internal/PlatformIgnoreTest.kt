package org.jetbrains.compose.resources.internal

@OptIn(ExperimentalMultiplatform::class)
@OptionalExpectation
expect annotation class IgnoreWasmTest()